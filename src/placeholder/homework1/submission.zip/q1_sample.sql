sqlite> SELECT DISTINCT(language)
   ...> FROM akas
   ...> ORDER BY language
   ...> LIMIT 10;